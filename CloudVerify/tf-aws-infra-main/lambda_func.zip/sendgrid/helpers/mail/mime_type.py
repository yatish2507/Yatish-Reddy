class MimeType(object):
    """The MIME type of the content included in your email.
    """
    text = "text/plain"
    html = "text/html"
    amp = "text/x-amp-html"
